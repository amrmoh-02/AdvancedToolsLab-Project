package myNewPackage;

import java.util.ArrayList;

public class CreateMenuRequest {

	int restaurantId;
	ArrayList<meal> meals = new ArrayList<>();
	
	
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public ArrayList<meal> getMeals() {
		return meals;
	}
	public void setMeals(ArrayList<meal> meals) {
		this.meals = meals;
	}
	
}
