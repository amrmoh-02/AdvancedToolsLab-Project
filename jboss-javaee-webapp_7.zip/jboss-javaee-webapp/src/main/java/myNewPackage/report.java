package myNewPackage;

import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Stateless
@Entity
public class report
{ 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int Id;
    
    int totalOrdersNum = 0;
    int totalCancelledNum = 0;
    int totalEarned = 0;
    
    @ManyToOne
    private restaurant restaurant;
    
    
    public restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(restaurant restaurant) {
		this.restaurant = restaurant;
	}
	public int getID() {
        return Id;
    }
    public void setID(int iD) {
        Id = iD;
    }
    public int getTotalOrdersNum() {
        return totalOrdersNum;
    }
    public void setTotalOrdersNum(int totalOrdersNum) {
        this.totalOrdersNum = totalOrdersNum;
    }
    public int getTotalCancelledNum() {
        return totalCancelledNum;
    }
    public void setTotalCancelledNum(int totalCancelledNum) {
        this.totalCancelledNum = totalCancelledNum;
    }
    public int getTotalEarned() {
        return totalEarned;
    }
    public void setTotalEarned(int totalEarned) {
        this.totalEarned = totalEarned;
    }

}